from dataclasses import dataclass, field
from typing import cast

import os
import subprocess
import torch

from transformers import HfArgumentParser, TrainingArguments, Trainer, DataCollatorForLanguageModeling
from utils.peft_utils import SaveDeepSpeedPeftModelCallback, create_and_prepare_model, load_data

from pathlib import Path
import yaml

from typing import Optional, List, Union, Dict, Any
from collections.abc import Mapping


# Define and parse arguments.
@dataclass
class ScriptArguments:
    """
    Additional arguments for training, which are not part of TrainingArguments.
    """
    model_path: str = field(
      metadata={
            "help": "The path to the Hugging Face model that you want to train."
        },
    )
    dataset_path: Optional[str] = field(
        default=Path("~/shared/uk1822/data/hybrid/Unsupervised_with_bilkent_140k__translation__qa_context_with_tfidf_closed_alternatives__upto_2048__total_800k.parquet").expanduser().as_posix(),
        metadata={"help": "The path to dataset to use."},
    )
    prompt_config_path: Optional[str] = field(
        default=Path("~/shared/uk1822/oktay/ai-uk1822-training/train_config.yaml").expanduser().as_posix(),
        metadata={"help": "The path to Yaml config for prompt."},
    )
    max_seq_length: Optional[int] = field(default=2048)
    lora_alpha: Optional[int] = field(default=32)
    lora_dropout: Optional[float] = field(default=0.1)
    lora_r: Optional[int] = field(default=64)
    use_flash_attn: Optional[bool] = field(
        default=False,
        metadata={"help": "Enables Flash attention for training."},
    )
    merge_adapters: bool = field(
        metadata={"help": "Wether to merge weights for LoRA."},
        default=False,
    )

@dataclass
class OurDataCollator(DataCollatorForLanguageModeling):
    def __init__(
        self,
        response_template: List[str],
        *args,
        mlm: bool = False,
        ignore_index: int = -100,
        **kwargs,
    ):
        super().__init__(*args, mlm=mlm, **kwargs)
        self.response_template = response_template
        self.ignore_index = ignore_index
        self.response_token_ids = [torch.tensor(self.tokenizer.encode(response_token)) for response_token in self.response_template]

    def torch_call(self, examples: List[Union[List[int], Any, Dict[str, Any]]]) -> Dict[str, Any]:
        # Handle dict or lists with proper padding and conversion to tensor.
        if isinstance(examples[0], Mapping):
            batch = self.tokenizer.pad(examples, return_tensors="pt", pad_to_multiple_of=self.pad_to_multiple_of)
        else:
            batch = {
                "input_ids": _torch_collate_batch(examples, self.tokenizer, pad_to_multiple_of=self.pad_to_multiple_of)
            }

        # If special token mask has been preprocessed, pop it from the dict.
        special_tokens_mask = batch.pop("special_tokens_mask", None)
        if self.mlm:
            batch["input_ids"], batch["labels"] = self.torch_mask_tokens(
                batch["input_ids"], special_tokens_mask=special_tokens_mask
            )
        else:
            labels = batch["input_ids"].clone()
            if self.tokenizer.pad_token_id is not None:
                labels[labels == self.tokenizer.pad_token_id] = self.ignore_index
            response_token_indices = [
                ((torch.ones(indx+len(response_token_id))*row_indx).to(torch.int), 
                 (torch.arange(indx+len(response_token_id))).to(torch.int)) 
                for response_token_id in self.response_token_ids 
                for row_indx, row in enumerate(labels) 
                for indx in range(len(row)-len(response_token_id), -1, -1) 
                    if all(
                        row[indx:indx+len(response_token_id)].cpu() == response_token_id
                    )
            ]
            if len(response_token_indices) > 0:
                row_indices, column_indices = zip(*response_token_indices)
                labels[torch.cat(row_indices), torch.cat(column_indices)] = self.ignore_index
            batch["labels"] = labels
        return batch


def training_function(script_args:ScriptArguments, training_args:TrainingArguments):

    #print("script_ars:", script_args, "training_args:", training_args)
    # Load and create peft model
    model, peft_config, tokenizer = create_and_prepare_model(script_args.model_path,training_args, script_args)
    model.config.use_cache = False


    # Load processed dataset from disk
    #dataset = load_from_disk(script_args.dataset_path)
    prompt_cfg = yaml.safe_load(open(script_args.prompt_config_path, 'r'))
    train_dataset, eval_dataset = load_data(tokenizer, prompt_cfg, script_args, training_args)
    

    our_data_collator = OurDataCollator(response_template=[prompt_cfg['load_data']['ANSWER_KEY']], tokenizer=tokenizer, mlm=False)


    # Create trainer and add callbacks
    trainer = Trainer(model=model, args=training_args, train_dataset=train_dataset, eval_dataset=eval_dataset, data_collator=our_data_collator)
    trainer.accelerator.print(f"{trainer.model}")
    trainer.model.print_trainable_parameters()
    trainer.add_callback(SaveDeepSpeedPeftModelCallback(trainer, save_steps=training_args.save_steps))
    
    print("model   dtype:", trainer.model.base_model.model.transformer.word_embeddings.weight.dtype)
    print("adapter dtype:", trainer.model.base_model.model.transformer.h[0].self_attention.query_key_value.lora_A.default.weight.dtype)
    print("")
    # print("model device details:")

    # for name, module in model.named_modules():
    #     if hasattr(module, "weight"):
    #         print(name, "->", module.weight.device, ",", module.weight.dtype)

    # Start training
    trainer.train()

    # Save model on main process
    trainer.accelerator.wait_for_everyone()
    state_dict = trainer.accelerator.get_state_dict(trainer.deepspeed)
    unwrapped_model = trainer.accelerator.unwrap_model(trainer.deepspeed)
    if trainer.accelerator.is_main_process:
        unwrapped_model.save_pretrained(training_args.output_dir, state_dict=state_dict)
    trainer.accelerator.wait_for_everyone()

    # TODO: add merge adapters
    # Save everything else on main process
    if trainer.args.process_index == 0:
        if script_args.merge_adapters:
            # merge adapter weights with base model and save
            # save int 4 model
            trainer.model.save_pretrained(training_args.output_dir, safe_serialization=False)
            # clear memory
            del model
            del trainer
            torch.cuda.empty_cache()

            from peft import AutoPeftModelForCausalLM

            # load PEFT model in fp16
            model = AutoPeftModelForCausalLM.from_pretrained(
                training_args.output_dir,
                low_cpu_mem_usage=True,
                torch_dtype=torch.float16,
            )  
            # Merge LoRA and base model and save
            model = model.merge_and_unload()        
            model.save_pretrained(
                training_args.output_dir, safe_serialization=True, max_shard_size="8GB"
            )
        else:
            trainer.model.save_pretrained(
                training_args.output_dir, safe_serialization=True
            )

        # save tokenizer 
        tokenizer.save_pretrained(training_args.output_dir)


def main():
    parser = HfArgumentParser([ScriptArguments,TrainingArguments])
    script_args, training_args = parser.parse_args_into_dataclasses()
    script_args = cast(ScriptArguments, script_args)
    training_args = cast(TrainingArguments, training_args)
    
    training_function(script_args, training_args)


if __name__ == "__main__":
    main()
