import torch
from torch.nn import LayerNorm
from transformers import TrainerCallback, TrainingArguments, TrainerState, TrainerControl
from peft import LoraConfig, get_peft_model
from peft.tuners.lora import LoraLayer
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
)
from datasets import load_from_disk, Dataset, load_dataset
import pandas as pd
from pathlib import Path

#from functools import partial
#import torch.utils.checkpoint
#from utils.falcon_patch import replace_attn_with_flash_attn as replace_falcon_attn_with_flash_attn
#from utils.llama_patch import replace_attn_with_flash_attn as replace_llama_attn_with_flash_attn


class SaveDeepSpeedPeftModelCallback(TrainerCallback):
    def __init__(self, trainer, save_steps=500):
        self.trainer = trainer
        self.save_steps = save_steps

    def on_step_end(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        **kwargs,
    ):
        if (state.global_step + 1) % self.save_steps == 0:
            self.trainer.accelerator.wait_for_everyone()
            state_dict = self.trainer.accelerator.get_state_dict(self.trainer.deepspeed)
            unwrapped_model = self.trainer.accelerator.unwrap_model(self.trainer.deepspeed)
            if self.trainer.accelerator.is_main_process:
                unwrapped_model.save_pretrained(args.output_dir, state_dict=state_dict)
            self.trainer.accelerator.wait_for_everyone()
        return control


def load_data(tokenizer, prompt_cfg, script_args, training_args):
    data_path = script_args.dataset_path
    data_format = Path(data_path).suffix[1:]
    if data_format == "jsonl": data_format = "json"

    if data_format == "csv":
        df = pd.read_csv(data_path, sep="|") # loading csv data from pandas is way faster
        data = Dataset.from_pandas(df)
    elif data_format == "parquet":
        df = pd.read_parquet(data_path, engine='pyarrow')
        data = Dataset.from_pandas(df)
    else:
        data = load_dataset(data_format, data_files=str(data_path))
    data = data.train_test_split(test_size=0.001)
    tokenize = generate_tokenize_func(generate_formatting_func(prompt_cfg['load_data'], tokenizer), tokenizer, script_args.max_seq_length)
    train_dataset = data['train'].map(
        tokenize,
        batched=True,
        remove_columns=data['train'].column_names,
        num_proc=8,
        batch_size=training_args.per_device_train_batch_size,
    )

    eval_dataset = data['test'].map(
        tokenize,
        batched=True,
        remove_columns=data['test'].column_names,
        num_proc=8,
        batch_size=training_args.per_device_eval_batch_size,
    )
    return train_dataset, eval_dataset

def prepare_qa(record, prompt_cfg, tokenizer, i):
    return f"""{record["intro"][i]}{prompt_cfg["CONTEXT_KEY"]}{record["context"][i]}{prompt_cfg["QUESTION_KEY"]}{record["instruction"][i]}{prompt_cfg["ANSWER_KEY"]}{record["response"][i]}{tokenizer.eos_token}"""

def prepare_summary(record, prompt_cfg, tokenizer, i):
    return f"""{prompt_cfg["ABSTRACT_KEY"]}{record["context"][i]}{prompt_cfg["SUMMARY_KEY"]}{record["response"][i]}{tokenizer.eos_token}"""

def prepare_qa_multi_context(record, prompt_cfg, tokenizer, i):
    return f"""{prompt_cfg['INTRO_QA']}{prompt_cfg["CONTEXT_KEY"]}{record["context"][i]}{prompt_cfg["CONTEXT_KEY"]}{record["context2"][i]}{prompt_cfg["CONTEXT_KEY"]}{record["context3"][i]}{prompt_cfg["QUESTION_KEY"]}{record["instruction"][i]}{prompt_cfg["ANSWER_KEY"]}{record["response"][i]}{tokenizer.eos_token}"""

def prepare_ner(record, prompt_cfg, tokenizer, i):
    return f"""{prompt_cfg["NER_CONTEXT_KEY"]}{record["context"][i]}{prompt_cfg["NER_CLASS_KEY"]}{record["entity"][i]}{prompt_cfg["NER_RESPONSE_KEY"]}{record["response"][i]}{tokenizer.eos_token}"""

def prepare_translation(record, prompt_cfg, tokenizer, i):
    return f"""{prompt_cfg["EN_KEY"]}{record["en"][i]}{prompt_cfg["TR_KEY"]}{record["tr"][i]}{tokenizer.eos_token}"""

def prepare_unsupervised(record, prompt_cfg, tokenizer, i):
    return f"""{record["context"][i]}{tokenizer.eos_token}"""

def generate_formatting_func(prompt_cfg, tokenizer):
    def formatting_func(data_point):
        return [
            prepare_qa(data_point, prompt_cfg, tokenizer, i) if data_point["category"][i]=='qa' else 
            prepare_translation(data_point, prompt_cfg, tokenizer, i) if data_point["category"][i]=='translation' else 
            prepare_summary(data_point, prompt_cfg, tokenizer, i) if data_point["category"][i]=='summarization' else 
            prepare_unsupervised(data_point, prompt_cfg, tokenizer, i)             
            for i in range(len(data_point["category"]))
        ]
    return formatting_func

def generate_tokenize_func(formatting_func, tokenizer, max_seq_length):
    def tokenize(element):
        outputs = tokenizer(
            formatting_func(element),
            truncation=True,
            padding=False,
            max_length=max_seq_length,
            return_overflowing_tokens=False,
            return_length=False
        )
        return {"input_ids": outputs["input_ids"], "attention_mask": outputs["attention_mask"]}
    return tokenize


def create_and_prepare_model(model_path: str, training_args: TrainingArguments, script_args):
    #torch.utils.checkpoint.checkpoint = partial(torch.utils.checkpoint.checkpoint, use_reentrant=True)

    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        use_cache=not training_args.gradient_checkpointing,
        use_flash_attention_2=script_args.use_flash_attn,
    )
    print("model loaded")

    # find all linear modules in model for lora
    target_modules = find_all_linear_names(model)

    # create lora config
    peft_config = LoraConfig(
        lora_alpha=script_args.lora_alpha,
        lora_dropout=script_args.lora_dropout,
        r=script_args.lora_r,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=target_modules,
    )
    # enable gradient checkpointing
    if training_args.gradient_checkpointing:
        model.gradient_checkpointing_enable()

    # pre-process the model by upcasting the layer norms in float 32 for
    # Adapted from https://github.com/tmm1/axolotl/blob/2eda9e02a9d15a7a3f92b41f257d9844d72fc220/src/axolotl/utils/models.py#L338
    #print("pre-processing model for peft")
    #for name, module in model.named_modules():
    #    if isinstance(module, LoraLayer):
    #        module = module.to(torch.bfloat16)
    #    elif isinstance(module, LayerNorm):
    #        module = module.to(torch.float32)
    #    elif any(x in name for x in ["lm_head", "embed_tokens", "wte", "wpe"]):
    #        if hasattr(module, "weight"):
    #            module = module.to(torch.bfloat16)

    #print("pre-processing model for peft")
    #for name, module in model.named_modules():
    #    if hasattr(module, "weight") and (not isinstance(module, LayerNorm)):
    #        module = module.to(torch.bfloat16)

    
    # initialize peft model
    print("initializing peft model")
    model = get_peft_model(model, peft_config)

    #print("post-processing model after peft")
    #for name, module in model.named_modules():
    #    if "lora" in name:
    #        if hasattr(module, "weight"):
    #            module = module.to(torch.bfloat16)

    # logger.info parameters
    model.print_trainable_parameters()

    # tokenizer
    tokenizer = AutoTokenizer.from_pretrained(model_path, padding_side="right", truncation_side="left")

    return model, peft_config, tokenizer


def find_all_linear_names(model):
    cls = torch.nn.Linear
    lora_module_names = set()
    for name, module in model.named_modules():
        if isinstance(module, cls):
            names = name.split(".")
            lora_module_names.add(names[0] if len(names) == 1 else names[-1])

    if "lm_head" in lora_module_names:  # needed for 16-bit
        lora_module_names.remove("lm_head")
    return list(lora_module_names)
